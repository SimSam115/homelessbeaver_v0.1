var htmlPageStart =`
<div id="title">

	<h1> HELLO! </h1>
	<p> My name is </p>
	<br> <h2> Samuel Haffner </h2> <br>
	<p style="font-size:32px;">and this is my Portfolio</p>
	<br><br>
	<h2> Take a look at what I've done</h2>
	<div style="margin: auto;">
		<img onclick="loadPage('pageProjects')" class="projectButton" src="images/title/goldenTicketButton.png" alt="Image">
		<img onclick="loadPage('pageProjects')" class="projectButton" src="images/title/ecoDropButton.png" alt="Image">
		<img onclick="loadPage('pageProjects')" class="projectButton" src="images/title/resonateButton.png" alt="Image">
		<img onclick="loadPage('pageProjects')" class="projectButton" src="images/title/batch17Button.png" alt="Image">
	</div>
	<br><br>
	<p>
	<img src="images/me2.png" alt="Image" style="float:right; width:25%; border-radius: 50%; margin:10px 40px 0px 0px;">
    <span style="font-family:lemonMilk;"> That's me.</span>
	I am a huge fan video games and I also have a huge passion for making them, I like to create games by programming on Unity. Although my passion is video games, I'm also interested in programming firewalls, drones, or artificial intelligence. 
	I'm confident in skills I'm gaining from my projects as well as the things I teach myself. I am ultimately seeking employment as part of a software development team/project.
	</p>
	<br><br>
	<p>
	I have skills in programming: C++ C# Java | HTML CSS Javascript 
	</p>
</div>
`

var htmlPageAbout = `
<div id="about">
	<img src="images/me.png" alt="Image">
	<div>
		<h2>A Hunter for Something More</h2>
		
		<div class="section">
			<img src="images/kidme.png" alt="Image">
			<h3>A little about me:</h3>
			<p>
			I am a very passionate person when it comes to the things I care about and love to do. At a young age I dreamt of becoming an architect. 
			I absolutely loved building but when I got into high school and took a CAD class, I realized I didn't like the rules and regulations of buildings. I switched to 3D modeling and discovered something I loved doing. 
			I spent the next two years in 3D modeling classes making spaceships, gorillas, a wolf, and drones that imagined would work great for games. 
			3D modeling is still one of my hobbies and I like to create small games with my models. While taking those classes, I registered for an introductory course in computer science. 
			After starting that class, I decided that was my future. The class was meant to guide kids along at a leisurely pace, but I was too interested to stay at their pace. 
			I would go out on the internet and learn as much as I could at home, learning about things weeks before the teacher brought them up in class. The only other class the school offered was an AP computer science course. I loved it and excelled in the class and scored excellently, which helped me skip 6 credits at Lawrence Technological University.
			</p>
		</div>
		
		<div class="section">
			<h3>Where I am now: </h3>
			<p style = "line-height:30px;">
			I'm currently enrolled at Lawrence Technological University pursuing a Computer Science degree with a focus on Software Development. The game design aspect of my degree is where I invest my programming skills. 

			</p>

			<p>
			<img src="images/sigmaPi.png" alt="Image" style="float:left; width:35%; border-radius: 10%;">
			I'm part of a fraternity called <a href ="https://sigmapi.org/" target="_blank">Sigma Pi</a>  who have helped me become the person I am today. I'm more confident in my skills and I am able to be who I am while pursuing my goals.
			
			
			</p>
			<p>
			Currently job hunting and applying to said jobs. I'm looking for jobs to help achieve my ultimate goal to become a Computer Programming Project Manager/Leader for Applications 
	(and maybe one day own my own video game company.)
			</p>
		</div>
	</div>
	
</div>
`

var htmlPageProjects = 
`

<h1 class="titleForProjects">Current Projects</h1>
<div id="projects">
	<div class="project">
		<img class="goldenCoupon" src="images/goldenCoupon.png" style= "width: 100%;" alt="Image">
		<h2>The Race for the Golden Coupon</h2>
		<p> 
		is a game where the player tests their skills in a shopping cart race to gain the ultimate prize of a golden ticket. It starts with running around the map collecting parts and abilities to use for the next phase of the game: cart racing! You must race against others striving for the Golden Ticket.
		
		
		</p>
		<div> </div>
		<h3>Background</h3>
		<p> 
		This is my latest game that I am working on in school. I've done all of the programming in the project. I've programmed the Racer's AI using Unity and the Physics Movement and hand-coded GUI.
		</p>
	</div>
	<div class="project">
		<img class="geoDrop" src="images/recyclingGameshow.png" alt="Image">
		<h2>EcoDrop</h2>
		<p> 
		is a game about the importance of recycling. The object is the learn which items should and shouldnt be collected. Follow a map
		
		
		</p>
		<div>
		</div>
		<h3>Background</h3>
		<p> 
		I'm the main programmer for this project, which is the brainchild of a Graphic Design senior that wanted a game for her thesis. I joined her and am now excited to show this game as one of my more time extensive projects!
		</p>
	</div>
</div>
<h1 class="titleForProjects">Past Projects</h1>
<div id="projects">
	<div class="project">
		<img class="resonate" style =" border-radius: 25%;" src="images/resonate.gif" alt="Image">
		<h2>Resonate</h2>
		<p> 
		is a game about being blind and solving a mad man's puzzles to escape to freedom, we hope.
		
		</p>
		<div>
		</div>
		<h3>Background</h3>
		<p> 
		This game was part of a 48 Hour Game Jam. 
		In a team of 5 people, I was the level designer dealing with where the player wakes up and how the player continues from each point. 
		I took into account where the player would be looking, should be looking and where they could be looking. It was a fun and an interesting challenge. I had a blast working with other people and hope to be doing more of these types of projects in the future.
		</p>
	</div>
	<div class="project">
		<img class="project" style = "box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);" src="images/batch17.png" alt="Image">
		<h2>Batch 17</h2>
		<p> 
		
		Batch 17 is an action / exploration game with physical, environmental puzzle set on the mining asteroid colonies of Sigma 6. 
		Every new piece of loot gives you access to a new section of the world for you to explore and conquer, and with no loading times, you're always encouraged to see what you may have missed.
		
		<a href ="http://www.indiedb.com/games/batch-17"> Batch-17 Baffled Media </a>
		</p>
		<h3>Background</h3>
		<p> 
		
		For this game, I was contract hired to do level designing work (about 10 hours a week).
		</p>
	</div>
</div>
`

var htmlPageContact = `
<div id="contact">
	<h1>How to reach me!</h1>
	<div>
		<a target="_blank" href="https://www.linkedin.com/in/samuel-haffner-450400139/">
		<img width=25%; src="images/linkedIn.png" alt="Image">
		</a>
		
	</div>
</div>
`