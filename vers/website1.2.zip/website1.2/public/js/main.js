function setup() {
	loadPage("pageStart");
}
function draw() {
	
}
window.onbeforeunload = function () {
  window.scrollTo(0, 0);
}
function loadPage(name){
	window.scrollTo(0, 0);
	document.getElementById('pageTitleButton').className = "";
	document.getElementById('pageAboutButton').className = "";
	document.getElementById('pageProjectsButton').className = "";
	document.getElementById('pageContactButton').className = "";
	switch(name){
		case "pageStart":
			document.getElementById('home').innerHTML = htmlPageStart;
			document.getElementById('pageTitleButton').className = "current";
		break;
		case "pageAbout":
			document.getElementById('home').innerHTML = htmlPageAbout;
			document.getElementById('pageAboutButton').className = "current";
		break;
		case "pageProjects":
			document.getElementById('home').innerHTML = htmlPageProjects;
			document.getElementById('pageProjectsButton').className = "current";
		break;
		case "pageContact":
			document.getElementById('home').innerHTML = htmlPageContact;
			document.getElementById('pageContactButton').className = "current";
		break;
	}
}