var htmlPageStart =`
<div id="title">

	<h1> HELLO! </h1>
	<p> My name is </p>
	<br> <h2> Samuel Haffner </h2> <br>
	<p style="font-size:32px;">and this is my Portfolio</p>
	<br><br>
	
	<h2> Take a look at what I've done</h2>
	<div style="margin: auto;">
		<img onclick="loadPage('pageProjects', 100)" class="projectButton" src="images/title/goldenTicketButton.png" alt="Image" style="width:230px;height:190px;">
		<img onclick="loadPage('pageProjects', 600)" class="projectButton" src="images/title/ecoDropButton.png" alt="Image" style="width:200px;height:190px;">
		<img onclick="loadPage('pageProjects', 1000)" class="projectButton" src="images/title/resonateButton.png" href='#resonate' alt="Image" style="width:250px;height:190px;">
		<img onclick="loadPage('pageProjects', 3000)" class="projectButton" src="images/title/batch17Button.png" alt="Image" style="width:250px;height:190px;">
	</div>
	<br><br>
	
	<p>
		<img src="images/picsOfMe/me2.png" alt="Image" style="float:right; width:25%; border-radius: 50%; margin:10px 40px 0px 0px;">
		<span style="font-family:lemonMilk;"> That's me.</span>
		I am a huge fan video games and I also have a huge passion for making them, I like to create games by programming on Unity. Although my passion is video games, I'm also interested in programming firewalls, drones, or artificial intelligence. 
		I'm confident in skills I'm gaining from my projects as well as the things I teach myself. I am ultimately seeking employment as part of a software development team/project.
	</p>
</div>
`

var htmlPageAbout = `
<div id="about">
	<img src="images/picsOfMe/me.png" alt="Image">
	
	<h2>A Hunter for Something More</h2>
	<div class="section">
		<img src="images/picsOfMe/kidme.png" alt="Image">
		<h3>A little about me:</h3>
		<p>
		I am a very passionate person when it comes to the things I care about and love to do. At a young age I dreamt of becoming an architect. 
		I absolutely loved building but when I got into high school and took a CAD class, I realized I didn't like the rules and regulations of buildings. I switched to 3D modeling and discovered something I loved doing. 
		I spent the next two years in 3D modeling classes making spaceships, gorillas, a wolf, and drones that imagined would work great for games. 
		3D modeling is still one of my hobbies and I like to create small games with my models. While taking those classes, I registered for an introductory course in computer science. 
		After starting that class, I decided that was my future. The class was meant to guide kids along at a leisurely pace, but I was too interested to stay at their pace. 
		I would go out on the internet and learn as much as I could at home, learning about things weeks before the teacher brought them up in class. The only other class the school offered was an AP computer science course. I loved it and excelled in the class and scored excellently, which helped me skip 6 credits at Lawrence Technological University.
		</p>
	</div>
	
	<div class="section">
		<h3>Where I am now: </h3>
		<p style = "line-height:30px;">
		I'm currently enrolled at Lawrence Technological University pursuing a Computer Science degree with a focus on Software Development. The game design aspect of my degree is where I invest my programming skills. 

		</p>

		<p>
		<img src="images/picsOfMe/sigmaPi.png" alt="Image" style="float:left; width:35%; border-radius: 10%;">
		I'm part of a fraternity called <a href ="https://sigmapi.org/" target="_blank">Sigma Pi</a>  who have helped me become the person I am today. I'm more confident in my skills and I am able to be who I am while pursuing my goals.
		
		
		</p>
		<p>
		Currently job hunting and applying to said jobs. I'm looking for jobs to help achieve my ultimate goal to become a Computer Programming Project Manager/Leader for Applications 
		(and maybe one day own my own video game company.)
		</p>
	</div>
	<div class="section">
		<h3>My Skills: </h3>
		<p style = "font-size:22px;">
			Programming: C++ C# Java | HTML CSS Javascript 
		</p>
		<p>
		I've learned some serverside programming and learning more.
		</p>
		<p>
		<br>
		Huge amount of Game Design skills: Game Designing, Game Design Concepting, Level Design, Programming C#, Unity, Gamemaker.
		</p>
	</div>
</div>
`

var htmlPageProjects = 
`

<h1 class="titleForProjects">Current Projects</h1>
<div id="projects">
	<a name="goldenCoupon"></a>
	<div id="goldenCouponDiv" class="project">
		<img class="goldenCoupon" src="images/projects/goldenCoupon.png" style= "width: 100%;" alt="Image">
		<h2>The Race for the Golden Coupon</h2>
		<p> 
		is a game where the player tests their skills in a shopping cart race to gain the ultimate prize of a golden ticket. It starts with running around the map collecting parts and abilities to use for the next phase of the game: cart racing! You must race against others striving for the Golden Ticket.
		<br>
		There are abilities that you collect before the race that help you place first against all the others.
		</p>
		<div> </div>
		<h3>Background</h3>
		<p> 
		This is my latest game that I am working on in school. I've done all of the programming in the project. I've programmed the Racer's AI using Unity and the Physics Movement and hand-coded GUI.
		</p>
	</div>
	<div id="geoDropDiv" class="project">
		<img class="geoDrop" src="images/projects/recyclingGame.png" alt="Image">
		<h2>EcoDrop</h2>
		<p> 
		is a game about the importance of recycling. The object is the learn which items should and shouldnt be collected.
		
		
		</p>
		<div>
		</div>
		<h3>Background</h3>
		<p> 
		I'm the main programmer for this project, which is the brainchild of a Graphic Design senior that wanted a game for her thesis. I joined her and am now excited to show this game as one of my more time extensive projects. 
		</p>
	</div>
</div>
<h1 class="titleForProjects">Past Projects</h1>
<div id="projects">
	<a name="resonate"></a>
	<div id="resonateDiv" class="project">
		<img class="resonate" style =" border-radius: 25%;" src="images/projects/resonate.gif" alt="Image">
		<h2>Resonate</h2>
		<p> 
		is a game about being blind and solving a mad man's puzzles to escape to freedom, you hope. You wake up beside a table with no idea where or what happened. As you look up you can see the clock have these colors resonating every second that passes. Distantly heard, a faucet with a leaky spout pulls your attention and those expanding rings reveal a safe sitting on a table with every plunk. Maybe the safe will help you escape, or only put you farther into this test... 
		
		</p>
		<div>
		</div>
		<h3>Background</h3>
		<p> 
		This game was part of a 48 Hour Game Jam. <a href"http://globalgamejam.org/" target="_blank">The Game Jam</a> is a what you can guess, a 48 hour straight game design challenge. LTU's Game Development Program hosted it for anyone to take part. There were about 20 people and they are split into teams. I was in a team of five people and my position was the games level designer. My team then consisted of two 3D artists and two programmers both of which I had to work with in order to get the level built. I had a blast working with other people and hope to be doing more of these types of projects in the future.
		<br>
		Every Game Jam has a Theme, this year was waves. So our team came up with the idea to make a puzzle game using sound as sight. This effect was just an expanding sphere that resonates like sound. This cool effect was used on things such as water dropping into a sink, making a plunk sound, or a clock on the wall. When things hit the ground they do the same effect. This allowed me to create unqiue ways of getting the players attention, or in this way while using the sound. I made a puzzle game that has the play move a square in a certain maze that could only be seen with the sound waves. The Mazes are on screens that the player had to press either buttons or real world objects to move a square to the mazes finish.
		<br>
		I dealt with where the player wakes up and how the player continues from each point. I also took into account where the player would be looking, should be looking and where they could be looking.
		<br>
		It was a fun and an interesting challenge. 
		</p>
	</div>
	<div id="batchdiv" class="project">
		<img class="project" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);" src="images/projects/batch17.png" alt="Image">
		<h2>Batch 17</h2>
		<p> 
		
		Batch 17 is an action / exploration game with physical, environmental puzzle set on the mining asteroid colonies of Sigma 6. 
		Every new piece of loot gives you access to a new section of the world for you to explore and conquer, and with no loading times, you're always encouraged to see what you may have missed.
		
		<a href ="http://www.indiedb.com/games/batch-17"> Batch-17 Baffled Media </a>
		</p>
		<h3>Background</h3>
		<p> 
		
		For this game, I was contract hired to do level designing work (about 10 hours a week).
		</p>
		<br><br><br><br><br><br>
	</div>
</div>
`

var htmlPageContact = `
<div id="contact">
	<h1>How to reach me!</h1>
	<div>
		<h2 style="text-align:center;">Email: haffnersam@gmail.com</h2>
		<a target="_blank" href="https://www.linkedin.com/in/samuel-haffner-450400139/">
			<i class="fa fa-linkedin-square fa-5x" aria-hidden="true" style="font-size:250px; text-align:center;"></i>
		</a>
		<a target="_blank" href="https://www.facebook.com/sam.haffner">
			<i class="fa fa-facebook-square" aria-hidden="true" style="font-size:250px; text-align:center;"></i>
		</a>
		<a target="_blank" href="https://plus.google.com/u/0/102963727069695093648">
			<i class="fa fa-google-plus fa-5x" aria-hidden="true" style="font-size:250px; text-align:center;"></i>
		</a>
	</div>
</div>
`