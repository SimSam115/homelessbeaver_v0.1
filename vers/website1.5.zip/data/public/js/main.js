function changePopupBox(which){
	document.getElementById("popuptext").innerHTML = which;
}